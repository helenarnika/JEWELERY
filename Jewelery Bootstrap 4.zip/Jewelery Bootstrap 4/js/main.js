$(function () {
    $('.hamburger').click(function () {
        $('.menu').toggleClass('visible');
    })
})